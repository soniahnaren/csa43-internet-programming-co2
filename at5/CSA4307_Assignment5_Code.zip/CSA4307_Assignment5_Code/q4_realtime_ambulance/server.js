'use strict';
/**
 * Live ambulance tracking + vitals streaming.
 *   ambulance (role "ambulance") --location/vitals--> server --broadcast--> hospital dashboards (role "hospital")
 * Start:  node server.js     (set TLS_KEY / TLS_CERT to serve WSS, ALLOWED_ORIGINS to restrict browsers)
 */
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { WebSocketServer, WebSocket } = require('ws');
const { verifyToken, makeToken } = require('./auth');

function start({ port = 8085, heartbeatMs = 15000, allowedOrigins = (process.env.ALLOWED_ORIGINS || 'http://localhost:8085,http://127.0.0.1:8085').split(',') } = {}) {
  const handler = (req, res) => {
    if (req.url === '/health') { res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end('{"status":"ok"}'); }
    if (req.url === '/' || req.url === '/index.html') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; connect-src 'self' ws: wss:" });
      return res.end(fs.readFileSync(path.join(__dirname, 'public', 'index.html')));
    }
    if (process.env.DEMO === '1' && req.url === '/demo-token') {                // demo only: a real system issues tokens after login
      res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end(makeToken({ role: 'hospital', sub: 'demo-viewer' }));
    }
    res.writeHead(404); res.end();
  };
  const server = process.env.TLS_KEY
    ? https.createServer({ key: fs.readFileSync(process.env.TLS_KEY), cert: fs.readFileSync(process.env.TLS_CERT) }, handler)
    : http.createServer(handler);
  if (!process.env.TLS_KEY) console.warn('WARNING: running without TLS (ws://). Use WSS in production.');

  const wss = new WebSocketServer({
    noServer: true,
    maxPayload: 4 * 1024,                                   // vitals messages are tiny; refuse big frames
    handleProtocols: (protocols) => (protocols.has('ambulance.v1') ? 'ambulance.v1' : false),
  });

  let seq = 0;
  const history = [];                                       // ring buffer for resume after reconnect
  const latest = new Map();                                 // ambulanceId -> last location event (snapshot)
  const MAX_HISTORY = 500;

  // ---------- 1. HTTP Upgrade: origin check + authentication BEFORE the socket is accepted ----------
  server.on('upgrade', (req, socket, head) => {
    const reject = (code, text) => { socket.write(`HTTP/1.1 ${code} ${text}\r\nConnection: close\r\n\r\n`); socket.destroy(); };
    const origin = req.headers.origin;
    if (origin && !allowedOrigins.includes(origin)) return reject(403, 'Forbidden');       // blocks Cross-Site WebSocket Hijacking
    const protos = (req.headers['sec-websocket-protocol'] || '').split(',').map((s) => s.trim());
    const tokenProto = protos.find((p) => p.startsWith('token.'));
    const claims = tokenProto ? verifyToken(tokenProto.slice(6)) : null;
    if (!claims || !['ambulance', 'hospital'].includes(claims.role)) return reject(401, 'Unauthorized');
    wss.handleUpgrade(req, socket, head, (ws) => { ws.claims = claims; wss.emit('connection', ws, req); });
  });

  const send = (ws, obj) => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); };
  const num = (v, lo, hi) => typeof v === 'number' && Number.isFinite(v) && v >= lo && v <= hi;

  function publish(evt) {
    evt.seq = ++seq; evt.serverTime = Date.now();
    history.push(evt); if (history.length > MAX_HISTORY) history.shift();
    if (evt.type === 'location') latest.set(evt.ambulanceId, evt);
    const data = JSON.stringify(evt);
    for (const c of wss.clients) {
      if (c.claims.role !== 'hospital' || c.readyState !== WebSocket.OPEN) continue;
      if (c.watch && c.watch !== evt.ambulanceId) continue;
      if (c.bufferedAmount > 1_000_000 && evt.type === 'location') continue;     // slow consumer: drop old positions, keep alerts/vitals
      c.send(data);
    }
  }

  // ---------- 2. Connection life-cycle ----------
  wss.on('connection', (ws) => {
    ws.isAlive = true; ws.msgCount = 0; ws.windowStart = Date.now();
    ws.on('pong', () => { ws.isAlive = true; });                                     // heartbeat reply
    ws.on('error', (e) => console.warn('socket error:', e.code || e.message));       // WITHOUT this an oversized/invalid frame crashes the process

    send(ws, { type: 'welcome', role: ws.claims.role, sub: ws.claims.sub, heartbeatMs });
    if (ws.claims.role === 'hospital') for (const loc of latest.values()) send(ws, loc);   // snapshot for new viewers

    ws.on('message', (raw, isBinary) => {
      if (isBinary) return ws.close(1003, 'text only');
      const now = Date.now();                                                         // per-connection rate limit (30 msg/s)
      if (now - ws.windowStart > 1000) { ws.windowStart = now; ws.msgCount = 0; }
      if (++ws.msgCount > 30) return ws.close(1008, 'rate limit');

      let m; try { m = JSON.parse(raw.toString()); } catch { return send(ws, { type: 'error', message: 'invalid JSON' }); }

      if (ws.claims.role === 'ambulance') {
        const base = { ambulanceId: ws.claims.sub, clientTs: m.ts };                  // identity comes from the token, never from the message
        if (m.type === 'location' && num(m.lat, -90, 90) && num(m.lng, -180, 180)) {
          return publish({ ...base, type: 'location', lat: m.lat, lng: m.lng, speed: num(m.speed, 0, 250) ? m.speed : 0 });
        }
        if (m.type === 'vitals' && num(m.hr, 0, 300) && num(m.spo2, 0, 100)) {
          const alert = m.spo2 < 90 || m.hr > 150 || m.hr < 40;                       // simple critical-vitals rule
          return publish({ ...base, type: 'vitals', hr: m.hr, spo2: m.spo2, sbp: m.sbp, dbp: m.dbp, alert });
        }
        return send(ws, { type: 'error', message: 'invalid message' });
      }
      // hospital
      if (m.type === 'subscribe') { ws.watch = typeof m.ambulanceId === 'string' ? m.ambulanceId.slice(0, 40) : null; return send(ws, { type: 'subscribed', ambulanceId: ws.watch }); }
      if (m.type === 'resume' && Number.isInteger(m.lastSeq)) {                       // replay what was missed while disconnected
        for (const e of history) if (e.seq > m.lastSeq && (!ws.watch || ws.watch === e.ambulanceId)) send(ws, e);
        return send(ws, { type: 'resumed', upTo: seq });
      }
      if (m.type === 'ping') return send(ws, { type: 'pong', t: m.t });               // application-level ping (browsers cannot see protocol pings)
    });
  });

  // ---------- 3. Heartbeat: detect half-open connections ----------
  const timer = setInterval(() => {
    for (const ws of wss.clients) {
      if (!ws.isAlive) { ws.terminate(); continue; }                                  // no pong since last round -> dead
      ws.isAlive = false; ws.ping();
      send(ws, { type: 'hb', t: Date.now() });                                        // lets browser code run its own watchdog
    }
  }, heartbeatMs);

  return new Promise((resolve) => server.listen(port, () => resolve({
    port: server.address().port, wss,
    close: () => new Promise((r) => { clearInterval(timer); for (const c of wss.clients) c.terminate(); wss.close(); server.close(r); }),
  })));
}

if (require.main === module) start({ port: Number(process.env.PORT) || 8085 }).then((s) => console.log(`listening on :${s.port}`));
module.exports = { start };
