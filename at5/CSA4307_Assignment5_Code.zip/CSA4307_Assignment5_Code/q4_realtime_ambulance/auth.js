'use strict';
const crypto = require('crypto');
const SECRET = process.env.WS_SECRET || 'dev-secret-change-me';

const b64 = (b) => Buffer.from(b).toString('base64url');

/** Short-lived signed token: base64url(payload).signature  (a real system would use OAuth 2.0 / JWT from the hospital IdP) */
function makeToken({ role, sub, ttlSec = 3600 }) {
  const payload = b64(JSON.stringify({ role, sub, exp: Math.floor(Date.now() / 1000) + ttlSec }));
  const sig = crypto.createHmac('sha256', SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifyToken(token) {
  if (typeof token !== 'string') return null;
  const [payload, sig] = token.split('.');
  if (!payload || !sig) return null;
  const expected = crypto.createHmac('sha256', SECRET).update(payload).digest();
  const given = Buffer.from(sig, 'base64url');
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) return null;   // constant-time compare
  try {
    const c = JSON.parse(Buffer.from(payload, 'base64url').toString());
    if (!c.exp || c.exp < Date.now() / 1000) return null;                                         // expired
    return c;
  } catch { return null; }
}
module.exports = { makeToken, verifyToken };
