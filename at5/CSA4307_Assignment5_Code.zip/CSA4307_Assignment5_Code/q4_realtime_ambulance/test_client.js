'use strict';
/** Automated checks: node test_client.js */
const WebSocket = require('ws');
const { start } = require('./server');
const { makeToken } = require('./auth');

const ORIGIN = 'http://127.0.0.1:8085';
const open = (port, role, sub, o = {}) => new Promise((res, rej) => {
  const ws = new WebSocket(`ws://127.0.0.1:${port}`, ['ambulance.v1', 'token.' + (o.token || makeToken({ role, sub }))], { origin: o.origin ?? ORIGIN, ...(o.autoPong === false ? { autoPong: false } : {}) });
  ws.msgs = []; ws.on('message', (d) => ws.msgs.push(JSON.parse(d)));
  ws.on('open', () => res(ws)); ws.on('error', (e) => rej(e));
  ws.on('unexpected-response', (_q, r) => rej(new Error('HTTP ' + r.statusCode)));
});
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const closed = (ws) => new Promise((r) => ws.on('close', (code) => r(code)));
let fails = 0; const check = (name, ok, extra = '') => { console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); if (!ok) fails++; };

(async () => {
  const srv = await start({ port: 0, heartbeatMs: 300, allowedOrigins: [ORIGIN] });
  const p = srv.port;

  // 1-3 handshake security
  await open(p, 'hospital', 'h1', { origin: 'http://evil.example' }).then(() => check('foreign Origin rejected', false), (e) => check('foreign Origin rejected', /403/.test(e.message), e.message));
  await open(p, 'hospital', 'h1', { token: 'garbage.token' }).then(() => check('forged token rejected', false), (e) => check('forged token rejected', /401/.test(e.message), e.message));
  const old = makeToken({ role: 'hospital', sub: 'x', ttlSec: -5 });
  await open(p, 'hospital', 'h1', { token: old }).then(() => check('expired token rejected', false), (e) => check('expired token rejected', /401/.test(e.message), e.message));

  // 4 latency: ambulance -> server -> hospital
  const hosp = await open(p, 'hospital', 'doc1'); const amb = await open(p, 'ambulance', 'AMB-07');
  const lat = [];
  const waitFor = (ws, pred, ms = 1000) => new Promise((res, rej) => {
    const t0 = Date.now();
    (function poll() { const m = ws.msgs.find(pred); if (m) return res(m); if (Date.now() - t0 > ms) return rej(new Error('timeout')); setTimeout(poll, 0); })();
  });
  for (let i = 0; i < 100; i++) {
    const tag = 1000 + i;                           // unique value so each reply is matched to its request
    const t0 = process.hrtime.bigint();
    amb.send(JSON.stringify({ type: 'vitals', hr: tag % 140 + 40, spo2: 97, sbp: 120, dbp: 80, ts: tag }));
    await waitFor(hosp, (m) => m.type === 'vitals' && m.clientTs === tag);
    lat.push(Number(process.hrtime.bigint() - t0) / 1e6);
    await wait(35);                                 // ~28 msg/s: stay below the 30 msg/s per-connection limit
  }
  lat.sort((a, b) => a - b);
  check('relay latency (localhost)', lat[94] < 25, `median ${lat[50].toFixed(2)} ms, p95 ${lat[94].toFixed(2)} ms (excludes real network)`);

  // 5 identity cannot be spoofed
  amb.send(JSON.stringify({ type: 'location', lat: 13.1, lng: 80.2, ambulanceId: 'AMB-99' })); await wait(80);
  const loc = hosp.msgs.filter((m) => m.type === 'location').pop();
  check('identity comes from token (spoof ignored)', loc && loc.ambulanceId === 'AMB-07');

  // 6 validation
  amb.send(JSON.stringify({ type: 'vitals', hr: 'abc', spo2: 99 })); await wait(60);
  check('invalid vitals rejected', amb.msgs.some((m) => m.type === 'error'));
  amb.send(JSON.stringify({ type: 'vitals', hr: 80, spo2: 85 })); await wait(60);
  check('critical SpO2 flagged as alert', hosp.msgs.filter((m) => m.type === 'vitals').pop().alert === true);

  // 7 oversized frame
  const big = await open(p, 'ambulance', 'AMB-08'); const bc = closed(big); big.send('x'.repeat(10000));
  check('oversized frame closes socket (1009)', (await bc) === 1009);

  // 8 hospital cannot publish
  hosp.send(JSON.stringify({ type: 'vitals', hr: 299, spo2: 99 })); await wait(60);
  check('hospital role cannot publish', !hosp.msgs.some((m) => m.type === 'vitals' && m.hr === 299));

  // 9 resume after disconnect
  const lastSeq = hosp.msgs.filter((m) => m.seq).pop().seq; hosp.close(); await wait(50);
  for (let i = 0; i < 3; i++) amb.send(JSON.stringify({ type: 'location', lat: 13 + i / 100, lng: 80 }));
  await wait(80);
  const h2 = await open(p, 'hospital', 'doc1'); h2.send(JSON.stringify({ type: 'resume', lastSeq })); await wait(120);
  check('missed events replayed after reconnect', h2.msgs.filter((m) => m.type === 'location' && m.seq > lastSeq).length >= 3);

  // 10 heartbeat kills a silent (half-open) client
  const dead = await open(p, 'hospital', 'zombie', { autoPong: false }); const dc = closed(dead);
  const code = await Promise.race([dc, wait(1500).then(() => 'still-open')]);
  check('unresponsive client terminated by heartbeat', code !== 'still-open', `close code ${code}`);

  // 11 rate limit
  const flood = await open(p, 'ambulance', 'AMB-09'); const fc = closed(flood);
  for (let i = 0; i < 60; i++) flood.send(JSON.stringify({ type: 'location', lat: 1, lng: 1 }));
  check('message flood closed (1008)', (await fc) === 1008);

  await srv.close(); console.log(fails ? `\n${fails} FAILED` : '\nall checks passed'); process.exit(fails ? 1 : 0);
})();
