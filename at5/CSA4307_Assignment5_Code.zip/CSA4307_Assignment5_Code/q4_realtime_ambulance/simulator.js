'use strict';
/** Simulated ambulance: sends GPS every second and vitals twice a second. Usage: node simulator.js AMB-07 */
const WebSocket = require('ws');
const { makeToken } = require('./auth');
const id = process.argv[2] || 'AMB-07';
const url = process.env.WS_URL || 'ws://127.0.0.1:8085';
const ws = new WebSocket(url, ['ambulance.v1', 'token.' + makeToken({ role: 'ambulance', sub: id })], { origin: 'http://127.0.0.1:8085' });
let lat = 13.0827, lng = 80.2707, t = 0;
ws.on('open', () => {
  console.log(id, 'connected');
  setInterval(() => { lat += 0.0004; lng += 0.0003; ws.send(JSON.stringify({ type: 'location', lat, lng, speed: 55, ts: Date.now() })); }, 1000);
  setInterval(() => { t++; ws.send(JSON.stringify({ type: 'vitals', hr: Math.round(88 + 10 * Math.sin(t / 5)), spo2: t % 40 > 34 ? 88 : 97, sbp: 118, dbp: 76, ts: Date.now() })); }, 500);
});
ws.on('close', (c) => { console.log('closed', c); process.exit(0); });
ws.on('error', (e) => console.error(e.message));
