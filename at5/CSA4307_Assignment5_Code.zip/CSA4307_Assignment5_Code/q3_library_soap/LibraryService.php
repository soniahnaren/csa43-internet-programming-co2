<?php
declare(strict_types=1);

/** The business operations published through SOAP. */
final class LibraryService
{
    private const MAX_OPEN_LOANS = 3;
    private const LOAN_DAYS = 14;

    public function __construct(private PDO $pdo, private string $role) {}

    private function fault(string $code, string $msg): never { throw new SoapFault('Client', "$code: $msg"); }
    private function need(string $permission): void
    {
        $allowed = ['public' => ['read'], 'desk' => ['read', 'issue']][$this->role] ?? [];
        if (!in_array($permission, $allowed, true)) { $this->fault('ERR_FORBIDDEN', 'This API key may not perform this operation'); }
    }

    /** searchBook(keyword) */
    public function searchBook(object $p): array
    {
        $this->need('read');
        $kw = trim((string)($p->keyword ?? ''));
        if (mb_strlen($kw) < 2 || mb_strlen($kw) > 60) { $this->fault('ERR_INVALID_KEYWORD', 'keyword must be 2 to 60 characters'); }
        $like = '%' . addcslashes($kw, '%_\\') . '%';             // user-typed % and _ are matched literally
        $st = $this->pdo->prepare("SELECT id, title, author, isbn, available_copies FROM books
                                   WHERE title LIKE :k ESCAPE '\\' OR author LIKE :k ESCAPE '\\'
                                   ORDER BY title LIMIT 25");
        $st->execute([':k' => $like]);
        return ['book' => array_map(static fn($r) => [
            'id' => (int)$r['id'], 'title' => $r['title'], 'author' => $r['author'],
            'isbn' => $r['isbn'], 'available' => (int)$r['available_copies'] > 0], $st->fetchAll())];
    }

    /** getBookDetails(bookId) */
    public function getBookDetails(object $p): array
    {
        $this->need('read');
        $id = filter_var($p->bookId ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id === false) { $this->fault('ERR_INVALID_ID', 'bookId must be a positive integer'); }
        $st = $this->pdo->prepare('SELECT id, title, author, isbn, total_copies, available_copies FROM books WHERE id = :id');
        $st->execute([':id' => $id]);
        $r = $st->fetch();
        if (!$r) { $this->fault('ERR_NOT_FOUND', 'Book not found'); }
        return ['id' => (int)$r['id'], 'title' => $r['title'], 'author' => $r['author'], 'isbn' => $r['isbn'],
                'totalCopies' => (int)$r['total_copies'], 'availableCopies' => (int)$r['available_copies']];
    }

    /** issueBook(bookId, memberId): one atomic transaction */
    public function issueBook(object $p): array
    {
        $this->need('issue');
        $bookId   = filter_var($p->bookId ?? null,   FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $memberId = filter_var($p->memberId ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($bookId === false || $memberId === false) { $this->fault('ERR_INVALID_ID', 'bookId and memberId must be positive integers'); }

        $sqlite = $this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite';
        $sqlite ? $this->pdo->exec('BEGIN IMMEDIATE') : $this->pdo->beginTransaction();   // IMMEDIATE = take the write lock now
        try {
            // 1. lock the member row so two requests for the same member are serialised (MySQL: FOR UPDATE)
            $st = $this->pdo->prepare('SELECT active FROM members WHERE id = :m' . ($sqlite ? '' : ' FOR UPDATE'));
            $st->execute([':m' => $memberId]);
            $m = $st->fetch();
            if (!$m || !(int)$m['active']) { $this->fault('ERR_MEMBER', 'Member not found or inactive'); }

            // 2. business rules
            $st = $this->pdo->prepare('SELECT COUNT(*) FROM loans WHERE member_id = :m AND returned_at IS NULL');
            $st->execute([':m' => $memberId]);
            if ((int)$st->fetchColumn() >= self::MAX_OPEN_LOANS) { $this->fault('ERR_LIMIT', 'Member already has 3 books on loan'); }
            $st = $this->pdo->prepare('SELECT COUNT(*) FROM loans WHERE member_id = :m AND book_id = :b AND returned_at IS NULL');
            $st->execute([':m' => $memberId, ':b' => $bookId]);
            if ((int)$st->fetchColumn() > 0) { $this->fault('ERR_DUPLICATE', 'Member already has this book'); }

            // 3. atomic stock decrement: the WHERE clause makes overselling impossible
            $st = $this->pdo->prepare('UPDATE books SET available_copies = available_copies - 1
                                       WHERE id = :b AND available_copies > 0');
            $st->execute([':b' => $bookId]);
            if ($st->rowCount() !== 1) {
                $ex = $this->pdo->prepare('SELECT 1 FROM books WHERE id = :b');
                $ex->execute([':b' => $bookId]);
                if ($ex->fetchColumn()) { $this->fault('ERR_OUT_OF_STOCK', 'No copy of this book is available'); }
                $this->fault('ERR_NOT_FOUND', 'Book not found');
            }

            // 4. record the loan
            $due = (new DateTimeImmutable('today'))->modify('+' . self::LOAN_DAYS . ' days')->format('Y-m-d');
            $this->pdo->prepare('INSERT INTO loans (book_id, member_id, issued_at, due_date) VALUES (:b,:m,:t,:d)')
                      ->execute([':b' => $bookId, ':m' => $memberId, ':t' => gmdate('Y-m-d H:i:s'), ':d' => $due]);
            $loanId = (int)$this->pdo->lastInsertId();

            $sqlite ? $this->pdo->exec('COMMIT') : $this->pdo->commit();
            return ['loanId' => $loanId, 'dueDate' => $due];
        } catch (SoapFault $f) {
            $this->rollback($sqlite);                                                    // business error: undo everything
            throw $f;
        } catch (Throwable $e) {
            $this->rollback($sqlite);
            error_log('issueBook failed: ' . $e->getMessage());                          // details only in the server log
            throw new SoapFault('Server', 'ERR_INTERNAL: the request could not be completed');
        }
    }

    private function rollback(bool $sqlite): void
    {
        try { $sqlite ? $this->pdo->exec('ROLLBACK') : $this->pdo->rollBack(); } catch (Throwable) { /* nothing to roll back */ }
    }
}
