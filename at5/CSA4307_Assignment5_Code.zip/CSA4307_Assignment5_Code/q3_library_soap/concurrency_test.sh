#!/bin/sh
# 6 members try to borrow book 1 (only 2 copies) at the same moment. Exactly 2 must succeed.
URL=${URL:-http://127.0.0.1:8084/server.php}
for m in 1 2 3 4 5 6; do
  ( curl -s -H 'X-Api-Key: desk-key-456' -H 'Content-Type: text/xml' --data-binary \
    "<s:Envelope xmlns:s='http://schemas.xmlsoap.org/soap/envelope/' xmlns:l='urn:college:library'><s:Body><l:issueBook><l:bookId>1</l:bookId><l:memberId>$m</l:memberId></l:issueBook></s:Body></s:Envelope>" \
    "$URL" | grep -o 'loanId>[0-9]*\|ERR_[A-Z_]*' | head -1 | sed "s/^/member $m: /" ) &
done
wait
