CREATE DATABASE IF NOT EXISTS library CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE library;

CREATE TABLE books (
    id               INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    isbn             VARCHAR(17)  NOT NULL UNIQUE,
    title            VARCHAR(200) NOT NULL,
    author           VARCHAR(120) NOT NULL,
    total_copies     INT UNSIGNED NOT NULL,
    available_copies INT UNSIGNED NOT NULL,
    CONSTRAINT chk_copies CHECK (available_copies <= total_copies),   -- last line of defence (MySQL 8.0.16+)
    FULLTEXT KEY ft_title_author (title, author)
) ENGINE=InnoDB;                                                      -- InnoDB: transactions + row locks

CREATE TABLE members (
    id    INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name  VARCHAR(100) NOT NULL,
    active TINYINT(1)  NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE loans (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    book_id     INT UNSIGNED NOT NULL,
    member_id   INT UNSIGNED NOT NULL,
    issued_at   DATETIME     NOT NULL,
    due_date    DATE         NOT NULL,
    returned_at DATETIME     NULL,
    FOREIGN KEY (book_id)   REFERENCES books(id),
    FOREIGN KEY (member_id) REFERENCES members(id),
    INDEX idx_member_open (member_id, returned_at)
) ENGINE=InnoDB;

-- Least-privilege account used by the service:
-- CREATE USER 'lib_svc'@'localhost' IDENTIFIED BY 'ChangeMe!';
-- GRANT SELECT ON library.books TO 'lib_svc'@'localhost';
-- GRANT SELECT, UPDATE (available_copies) ON library.books TO 'lib_svc'@'localhost';
-- GRANT SELECT ON library.members TO 'lib_svc'@'localhost';
-- GRANT SELECT, INSERT ON library.loans TO 'lib_svc'@'localhost';
