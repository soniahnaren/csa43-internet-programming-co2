<?php
declare(strict_types=1);
/** Run: php -S 127.0.0.1:8084 server.php     WSDL: http://127.0.0.1:8084/server.php?wsdl */
require __DIR__ . '/db.php';
require __DIR__ . '/LibraryService.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
    if (isset($_GET['wsdl'])) { header('Content-Type: text/xml; charset=UTF-8'); readfile(__DIR__ . '/library.wsdl'); exit; }
    http_response_code(405); exit;
}

// ---- authentication: API key -> role (store only hashes in production) ----
$roles = [hash('sha256', 'public-key-123') => 'public', hash('sha256', 'desk-key-456') => 'desk'];
$role  = $roles[hash('sha256', $_SERVER['HTTP_X_API_KEY'] ?? '')] ?? null;
if ($role === null) {
    http_response_code(401);
    header('Content-Type: text/xml; charset=UTF-8');
    echo '<?xml version="1.0"?><SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"><SOAP-ENV:Body>'
       . '<SOAP-ENV:Fault><faultcode>SOAP-ENV:Client</faultcode><faultstring>ERR_UNAUTHORIZED: valid X-Api-Key required</faultstring>'
       . '</SOAP-ENV:Fault></SOAP-ENV:Body></SOAP-ENV:Envelope>';
    exit;
}
$raw = file_get_contents('php://input', false, null, 0, 16385);
if (strlen($raw) > 16384 || stripos($raw, '<!DOCTYPE') !== false) {          // size limit, no DTD / XXE
    http_response_code(400); exit;
}

$pdo = library_pdo();
if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') { seed_demo($pdo); }   // demo only

$server = new SoapServer(__DIR__ . '/library.wsdl', ['cache_wsdl' => WSDL_CACHE_NONE]);
$server->setObject(new LibraryService($pdo, $role));
$server->handle($raw);
