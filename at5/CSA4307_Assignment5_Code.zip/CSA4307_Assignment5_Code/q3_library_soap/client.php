<?php
declare(strict_types=1);
/** Consuming the service with PHP SoapClient. Usage: php client.php [search-word] */
$key = getenv('LIB_KEY') ?: 'desk-key-456';
$client = new SoapClient(__DIR__ . '/library.wsdl', [
    'location'       => getenv('LIB_URL') ?: 'http://127.0.0.1:8084/server.php',
    'stream_context' => stream_context_create(['http' => ['header' => "X-Api-Key: $key\r\n"]]),
    'cache_wsdl'     => WSDL_CACHE_NONE, 'exceptions' => true, 'trace' => true, 'connection_timeout' => 5,
]);

function toList(mixed $v): array { return $v === null ? [] : (is_array($v) ? $v : [$v]); }   // SoapClient gives one object when there is one row

try {
    // 1. build request -> call operation -> process response
    $found = $client->searchBook(['keyword' => $argv[1] ?? 'program']);
    foreach (toList($found->book ?? null) as $b) {
        printf("#%d %-32s %-24s %s\n", $b->id, $b->title, $b->author, $b->available ? 'available' : 'ALL ISSUED');
    }
    $d = $client->getBookDetails(['bookId' => 1]);
    printf("Details: %s - %d of %d copies available\n", $d->title, $d->availableCopies, $d->totalCopies);

    $loan = $client->issueBook(['bookId' => 1, 'memberId' => 1]);
    printf("Issued: loan #%d, due %s\n", $loan->loanId, $loan->dueDate);
} catch (SoapFault $f) {
    echo "SOAP FAULT [{$f->faultcode}]: {$f->faultstring}\n";               // 2. errors arrive as faults
}
