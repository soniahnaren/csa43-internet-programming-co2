-- Same model for the offline demo (SQLite). Production uses schema_mysql.sql.
CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT, isbn TEXT NOT NULL UNIQUE, title TEXT NOT NULL, author TEXT NOT NULL,
    total_copies INTEGER NOT NULL, available_copies INTEGER NOT NULL CHECK (available_copies >= 0));
CREATE TABLE IF NOT EXISTS members (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS loans (
    id INTEGER PRIMARY KEY AUTOINCREMENT, book_id INTEGER NOT NULL REFERENCES books(id),
    member_id INTEGER NOT NULL REFERENCES members(id), issued_at TEXT NOT NULL, due_date TEXT NOT NULL, returned_at TEXT);
