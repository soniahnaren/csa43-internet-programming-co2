<?php
declare(strict_types=1);

function library_pdo(): PDO
{
    $dsn  = getenv('LIB_DSN') ?: 'sqlite:' . (getenv('LIB_SQLITE') ?: sys_get_temp_dir() . '/library_demo.sqlite');
    $pdo  = new PDO($dsn, getenv('LIB_USER') ?: null, getenv('LIB_PASS') ?: null, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') {
        $pdo->exec('PRAGMA busy_timeout = 5000');            // wait for the write lock instead of failing at once
        $pdo->exec('PRAGMA foreign_keys = ON');
    }
    return $pdo;
}

/** Create demo tables and data (SQLite only). */
function seed_demo(PDO $pdo): void
{
    $pdo->exec(file_get_contents(__DIR__ . '/schema_sqlite.sql'));
    if ((int)$pdo->query('SELECT COUNT(*) FROM books')->fetchColumn() > 0) { return; }
    $pdo->exec("INSERT INTO books (isbn,title,author,total_copies,available_copies) VALUES
        ('978-0-13-468599-1','Internet Programming Basics','R. Kumar',2,2),
        ('978-0-13-110362-7','The C Programming Language','Kernighan and Ritchie',3,3),
        ('978-1-49-205201-0','Web Services with PHP','S. Devi',1,1)");
    for ($i = 1; $i <= 8; $i++) { $pdo->exec("INSERT INTO members (name) VALUES ('Member $i')"); }
}
