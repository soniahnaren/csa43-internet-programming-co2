<?php
declare(strict_types=1);
/** Usage: php client.php 192311234 5 */
$client = new SoapClient(__DIR__ . '/student_result.wsdl', [
    'location' => getenv('RESULT_URL') ?: 'http://127.0.0.1:8083/server.php',
    'stream_context' => stream_context_create(['http' => ['header' => "X-Api-Key: univ-demo-key\r\n"]]),
    'cache_wsdl' => WSDL_CACHE_NONE, 'exceptions' => true]);
try {
    $r = $client->getStudentResult(['registerNumber' => $argv[1] ?? '192311234', 'semester' => (int)($argv[2] ?? 5)]);
    printf("%s (%s) semester %d  GPA %.2f  %s\n", $r->studentName, $r->registerNumber, $r->semester, $r->gpa, $r->status);
    $subjects = is_array($r->subject) ? $r->subject : [$r->subject];
    foreach ($subjects as $s) { printf("  %-8s %-24s %d credits  %s\n", $s->code, $s->name, $s->credits, $s->grade); }
} catch (SoapFault $f) {
    echo "SOAP FAULT [{$f->faultcode}]: {$f->faultstring}\n";
}
