#!/bin/sh
# Usage: ./run_tests.sh   (server must be running: php -S 127.0.0.1:8083 server.php)
URL=${URL:-http://127.0.0.1:8083/server.php}
KEY='X-Api-Key: univ-demo-key'
run() {  # name file expected-text [header]
  out=$(curl -s -w '\n%{http_code} %{time_total}s' -H 'Content-Type: text/xml; charset=utf-8' \
        -H 'SOAPAction: "urn:university:results#getStudentResult"' -H "${4:-$KEY}" --data-binary @"$2" "$URL")
  if echo "$out" | grep -q "$3"; then r=PASS; else r=FAIL; fi
  printf '%-4s %-22s %s\n' "$r" "$1" "$(echo "$out" | tail -1)"
}
run "valid request"        tests/01_valid.xml         "<ns1:gpa>"
run "invalid register no." tests/02_invalid_regno.xml "ERR_INVALID_REGNO"
run "missing field"        tests/03_missing_field.xml "ERR_MISSING_FIELD"
run "unknown student"      tests/04_not_found.xml     "ERR_NOT_FOUND"
run "semester out of range" tests/05_bad_semester.xml "ERR_INVALID_SEMESTER"
run "XXE attack blocked"   tests/06_xxe_attack.xml    "ERR_FORBIDDEN_XML"
run "no API key"           tests/01_valid.xml         "ERR_UNAUTHORIZED" "X-Dummy: 1"
run "wrong API key"        tests/01_valid.xml         "ERR_UNAUTHORIZED" "X-Api-Key: guess"
