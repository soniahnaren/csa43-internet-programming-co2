<?php
declare(strict_types=1);
/** Run: php -S 127.0.0.1:8083 server.php   (WSDL: http://127.0.0.1:8083/server.php?wsdl) */

final class ResultService
{
    /** Demo data. A real service reads these rows from the university database with PDO. */
    private const DB = [
        '192311234' => ['name' => 'Anitha R', 'sem' => [5 => [
            ['CSA4307', 'Internet Programming', 4, 'A+'], ['CSA4301', 'Computer Networks', 4, 'A'],
            ['CSA4305', 'Operating Systems', 3, 'B+']]]],
        '192311999' => ['name' => 'Karthik S', 'sem' => [5 => [
            ['CSA4307', 'Internet Programming', 4, 'U'], ['CSA4301', 'Computer Networks', 4, 'C']]]],
    ];
    private const POINTS = ['O' => 10, 'A+' => 9, 'A' => 8, 'B+' => 7, 'B' => 6, 'C' => 5, 'U' => 0];

    public function getStudentResult(object $p): array
    {
        $reg = $p->registerNumber ?? null;
        $sem = $p->semester ?? null;
        if ($reg === null || $reg === '' || $sem === null || $sem === '') {
            throw new SoapFault('Client', 'ERR_MISSING_FIELD: registerNumber and semester are required');
        }
        if (!is_string($reg) || preg_match('/^[0-9]{9}\z/', $reg) !== 1) {
            throw new SoapFault('Client', 'ERR_INVALID_REGNO: register number must be exactly 9 digits');
        }
        if (!is_numeric($sem) || (int)$sem < 1 || (int)$sem > 8) {
            throw new SoapFault('Client', 'ERR_INVALID_SEMESTER: semester must be 1 to 8');
        }
        $row = self::DB[$reg]['sem'][(int)$sem] ?? null;
        if ($row === null) {
            throw new SoapFault('Client', 'ERR_NOT_FOUND: no result for this register number and semester');
        }
        $credits = 0; $points = 0; $fail = false; $subjects = [];
        foreach ($row as [$code, $name, $cr, $grade]) {
            $subjects[] = ['code' => $code, 'name' => $name, 'credits' => $cr, 'grade' => $grade];
            $credits += $cr; $points += $cr * self::POINTS[$grade]; $fail = $fail || $grade === 'U';
        }
        return ['registerNumber' => $reg, 'studentName' => self::DB[$reg]['name'], 'semester' => (int)$sem,
                'subject' => $subjects, 'gpa' => round($points / $credits, 2), 'status' => $fail ? 'FAIL' : 'PASS'];
    }
}

function soap_fail(string $code, string $msg, int $http = 200): never
{
    http_response_code($http);
    header('Content-Type: text/xml; charset=UTF-8');
    echo '<?xml version="1.0" encoding="UTF-8"?><SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">'
       . '<SOAP-ENV:Body><SOAP-ENV:Fault><faultcode>SOAP-ENV:' . $code . '</faultcode><faultstring>'
       . htmlspecialchars($msg, ENT_XML1) . '</faultstring></SOAP-ENV:Fault></SOAP-ENV:Body></SOAP-ENV:Envelope>';
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {            // publish the WSDL
    if (isset($_GET['wsdl'])) { header('Content-Type: text/xml; charset=UTF-8'); readfile(__DIR__ . '/student_result.wsdl'); exit; }
    http_response_code(405); exit;
}

// ---- security checks before any SOAP processing ----
$key = $_SERVER['HTTP_X_API_KEY'] ?? '';
if (!hash_equals(hash('sha256', 'univ-demo-key'), hash('sha256', $key))) {
    soap_fail('Client', 'ERR_UNAUTHORIZED: valid X-Api-Key header required', 401);
}
$raw = file_get_contents('php://input', false, null, 0, 16385);
if (strlen($raw) > 16384) { soap_fail('Client', 'ERR_TOO_LARGE: request too large', 413); }
if (stripos($raw, '<!DOCTYPE') !== false || stripos($raw, '<!ENTITY') !== false) {   // blocks XXE / entity-expansion attacks
    soap_fail('Client', 'ERR_FORBIDDEN_XML: DTDs are not allowed');
}

$server = new SoapServer(__DIR__ . '/student_result.wsdl', ['cache_wsdl' => WSDL_CACHE_NONE]);
$server->setObject(new ResultService());
$server->handle($raw);
