'use strict';
/**
 * Minimal PERMISSIONED ledger (teaching model of what Hyperledger Fabric provides):
 *  - blocks are linked by SHA-256 hashes (tamper evidence)
 *  - a transaction is accepted only if enough member organisations have signed it (endorsement policy = consensus step)
 *  - only members' public keys are known to the network (permissioned: no anonymous miners, no proof-of-work)
 */
const crypto = require('crypto');
const fs = require('fs');

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const canonical = (o) => JSON.stringify(o, Object.keys(o).sort());            // stable text for hashing/signing

class Org {                                                                   // a hospital / laboratory peer
  constructor(name) {
    this.name = name;
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
    this.publicKey = publicKey; this.privateKey = privateKey;                 // production: keys live in an HSM / Fabric CA
  }
  sign(digestHex) { return crypto.sign(null, Buffer.from(digestHex, 'hex'), this.privateKey).toString('base64'); }
}

class Ledger {
  constructor({ orgs, minEndorsements = 2, file = null }) {
    this.members = new Map(orgs.map((o) => [o.name, o.publicKey]));
    this.minEndorsements = minEndorsements;
    this.file = file;
    this.chain = [this.#make(0, '0'.repeat(64), [])];                          // genesis block
    if (file && fs.existsSync(file)) this.chain = JSON.parse(fs.readFileSync(file, 'utf8'));
  }

  #make(index, prevHash, txs) {
    const timestamp = new Date().toISOString();
    const body = { index, prevHash, timestamp, txs };
    return { ...body, hash: sha256(JSON.stringify(body)) };
  }

  static txDigest(tx) { return sha256(canonical(tx)); }

  /** Validate endorsements (each signature must verify, orgs must be distinct members) then append a block. */
  append(tx, endorsements) {
    const digest = Ledger.txDigest(tx);
    const good = new Set();
    for (const e of endorsements) {
      const key = this.members.get(e.org);
      if (key && crypto.verify(null, Buffer.from(digest, 'hex'), key, Buffer.from(e.signature, 'base64'))) good.add(e.org);
    }
    if (good.size < this.minEndorsements) {
      throw Object.assign(new Error(`endorsement policy not met (${good.size}/${this.minEndorsements})`), { code: 'ENDORSEMENT' });
    }
    const prev = this.chain[this.chain.length - 1];
    const block = this.#make(prev.index + 1, prev.hash, [{ ...tx, endorsedBy: [...good].sort() }]);
    this.chain.push(block);
    if (this.file) fs.writeFileSync(this.file, JSON.stringify(this.chain));
    return block;
  }

  /** Re-compute every hash and link. Any edit to any old block is detected here. */
  verify() {
    for (let i = 0; i < this.chain.length; i++) {
      const { hash, ...body } = this.chain[i];
      if (sha256(JSON.stringify(body)) !== hash) return { valid: false, brokenAt: i, reason: 'block content changed' };
      if (i > 0 && this.chain[i].prevHash !== this.chain[i - 1].hash) return { valid: false, brokenAt: i, reason: 'link broken' };
    }
    return { valid: true, height: this.chain.length - 1 };
  }

  get transactions() { return this.chain.flatMap((b) => b.txs.map((t) => ({ ...t, block: b.index, blockHash: b.hash }))); }
}
module.exports = { Ledger, Org, sha256, canonical };
