'use strict';
/**
 * Hyperledger Fabric chaincode (Node.js, fabric-contract-api) for the SAME rules as contract.js.
 * NOT EXECUTED in this submission: it needs a running Fabric test network (see README).
 * Endorsement policy (set at chaincode approval time): OutOf(2, 'HospitalAMSP.peer', 'HospitalBMSP.peer', 'HospitalCMSP.peer', 'LabXMSP.peer')
 */
const { Contract } = require('fabric-contract-api');

class HealthRecordsContract extends Contract {
  async registerRecord(ctx, recordId, patientId, contentHash) {
    const org = ctx.clientIdentity.getMSPID();
    if (!ctx.clientIdentity.assertAttributeValue('role', 'clinician')) throw new Error('only clinicians may register records');
    if ((await ctx.stub.getState(`REC_${recordId}`)).length) throw new Error('record already exists');
    await ctx.stub.putState(`REC_${recordId}`, Buffer.from(JSON.stringify({ recordId, patientId, contentHash, ownerOrg: org })));
  }

  async grantConsent(ctx, patientId, orgId, purpose, expiresAtIso) {
    if (ctx.clientIdentity.getAttributeValue('patientId') !== patientId) throw new Error('only the patient can grant consent');
    await ctx.stub.putState(`CON_${patientId}_${orgId}`, Buffer.from(JSON.stringify({ purpose, expiresAt: expiresAtIso, active: true })));
  }

  async revokeConsent(ctx, patientId, orgId) {
    if (ctx.clientIdentity.getAttributeValue('patientId') !== patientId) throw new Error('only the patient can revoke consent');
    await ctx.stub.deleteState(`CON_${patientId}_${orgId}`);
  }

  async checkConsentAndLog(ctx, recordId, purpose) {
    const org = ctx.clientIdentity.getMSPID();
    const rec = JSON.parse((await ctx.stub.getState(`REC_${recordId}`)).toString() || 'null');
    if (!rec) throw new Error('record not found');
    const raw = await ctx.stub.getState(`CON_${rec.patientId}_${org}`);
    const c = raw.length ? JSON.parse(raw.toString()) : null;
    const granted = rec.ownerOrg === org || (!!c && c.active && new Date(c.expiresAt) > new Date(ctx.stub.getTxTimestamp().seconds * 1000));
    // the transaction itself (with its timestamp and caller identity) is the immutable access log
    ctx.stub.setEvent('ACCESS', Buffer.from(JSON.stringify({ recordId, org, purpose, granted })));
    return JSON.stringify({ granted, contentHash: granted ? rec.contentHash : null });
  }
}
module.exports.contracts = [HealthRecordsContract];
