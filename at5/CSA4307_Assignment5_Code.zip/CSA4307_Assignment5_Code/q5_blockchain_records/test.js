'use strict';
/** End-to-end scenario: node test.js */
const os = require('os'), fs = require('fs'), path = require('path');
const { createApp } = require('./api');
const { Ledger } = require('./ledger');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ehr-'));
const app = createApp({ dir });
let fails = 0; const check = (n, ok, x = '') => { console.log((ok ? 'PASS ' : 'FAIL ') + n + (x ? '  ' + x : '')); if (!ok) fails++; };

app.server.listen(0, async () => {
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const call = async (method, url, tok, body) => {
    const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...(tok ? { Authorization: 'Bearer ' + tok } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const t = await r.text(); return { status: r.status, body: t ? JSON.parse(t) : null };
  };
  const A  = app.makeToken({ id: 'dr-asha', role: 'hospital', org: 'HospitalA' });
  const B  = app.makeToken({ id: 'dr-bala', role: 'hospital', org: 'HospitalB' });
  const L  = app.makeToken({ id: 'tech-lee', role: 'lab', org: 'LabX' });
  const P  = app.makeToken({ id: 'PAT-1001', role: 'patient', org: '-' });
  const P2 = app.makeToken({ id: 'PAT-2002', role: 'patient', org: '-' });

  check('no token -> 401', (await call('GET', '/v1/ledger/verify')).status === 401);

  const created = await call('POST', '/v1/records', A, { patientId: 'PAT-1001', content: 'Dx: type 2 diabetes. HbA1c 8.1%' });
  check('Hospital A stores record (hash on chain)', created.status === 201, `block ${created.body.block}`);
  const rid = created.body.recordId;
  const onChain = JSON.stringify(app.ledger.chain);
  check('chain holds no medical text', !onChain.includes('diabetes') && onChain.includes(created.body.contentHash));

  check('owner org can read', (await call('GET', `/v1/records/${rid}`, A)).status === 200);
  const denied = await call('GET', `/v1/records/${rid}`, B);
  check('Hospital B without consent -> 403', denied.status === 403);
  check('lab without consent -> 403', (await call('GET', `/v1/records/${rid}`, L)).status === 403);

  check("another patient cannot grant on PAT-1001's behalf", (await call('POST', '/v1/patients/PAT-1001/consents', P2, { orgId: 'HospitalB', days: 30 })).status === 403);
  check('patient grants Hospital B consent', (await call('POST', '/v1/patients/PAT-1001/consents', P, { orgId: 'HospitalB', days: 30, purpose: 'referral' })).status === 201);
  const ok = await call('GET', `/v1/records/${rid}?purpose=referral`, B);
  check('Hospital B with consent -> 200 and correct plaintext', ok.status === 200 && ok.body.content.includes('HbA1c'));

  const audit = await call('GET', `/v1/records/${rid}/audit`, P);
  check('patient sees full audit trail', audit.status === 200 && audit.body.events.length === 4,
        audit.body.events.map((e) => `${e.org}:${e.granted ? 'granted' : 'DENIED'}`).join(', '));
  check('hospital cannot read the audit trail', (await call('GET', `/v1/records/${rid}/audit`, B)).status === 403);

  check('patient revokes consent', (await call('DELETE', '/v1/patients/PAT-1001/consents/HospitalB', P)).status === 204);
  check('Hospital B blocked again after revoke', (await call('GET', `/v1/records/${rid}`, B)).status === 403);

  check('ledger verifies', (await call('GET', '/v1/ledger/verify', A)).body.valid === true);

  // endorsement policy
  const tx = { type: 'ACCESS', data: { recordId: rid }, actor: { id: 'x' }, ts: 'now' };
  let rejected = false; try { app.ledger.append(tx, [{ org: 'HospitalA', signature: app.contract.orgs[0].sign(Ledger.txDigest(tx)) }]); } catch (e) { rejected = e.code === 'ENDORSEMENT'; }
  check('1 endorsement < policy of 2 -> rejected', rejected);

  // off-chain tampering
  const f = path.join(dir, 'data', rid + '.json'); const orig = fs.readFileSync(f, 'utf8');
  const j = JSON.parse(orig); j.ct = Buffer.from('tampered').toString('base64'); fs.writeFileSync(f, JSON.stringify(j));
  check('altered off-chain data detected (hash mismatch) -> 409', (await call('GET', `/v1/records/${rid}`, A)).status === 409);
  fs.writeFileSync(f, orig);

  // on-chain tampering
  const saved = JSON.parse(JSON.stringify(app.ledger.chain));
  app.ledger.chain[2].txs[0].data.purpose = 'altered';
  const v = app.ledger.verify(); check('edited block detected', v.valid === false, `broken at block ${v.brokenAt}: ${v.reason}`);
  app.ledger.chain = saved;

  // right to erasure
  const er = await call('DELETE', `/v1/records/${rid}/content`, P);
  check('erasure request (crypto-shredding)', er.status === 200);
  check('content gone -> 410', (await call('GET', `/v1/records/${rid}`, A)).status === 410);
  check('keys and data files deleted', !fs.existsSync(f) && !fs.existsSync(path.join(dir, 'keys', rid + '.json')));
  check('ledger still valid after erasure (only a hash remains)', (await call('GET', '/v1/ledger/verify', A)).body.valid === true);

  app.server.close(); console.log(fails ? `\n${fails} FAILED` : `\nall checks passed (ledger height ${app.ledger.chain.length - 1})`); process.exit(fails ? 1 : 0);
});
