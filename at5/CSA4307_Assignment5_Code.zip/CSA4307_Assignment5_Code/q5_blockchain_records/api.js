'use strict';
/** REST web service between the hospital web app, the off-chain store and the blockchain. */
const http = require('http');
const crypto = require('crypto');
const { Ledger, Org } = require('./ledger');
const { HealthContract } = require('./contract');
const { OffChainStore } = require('./offchain');

const SECRET = process.env.API_SECRET || 'dev-secret-change-me';
const b64 = (b) => Buffer.from(b).toString('base64url');
const makeToken = (c) => { const p = b64(JSON.stringify({ ...c, exp: Math.floor(Date.now() / 1000) + 3600 })); return p + '.' + crypto.createHmac('sha256', SECRET).update(p).digest('base64url'); };
function verify(tok) {
  const [p, s] = String(tok || '').split('.'); if (!p || !s) return null;
  const e = crypto.createHmac('sha256', SECRET).update(p).digest(); const g = Buffer.from(s, 'base64url');
  if (g.length !== e.length || !crypto.timingSafeEqual(g, e)) return null;
  const c = JSON.parse(Buffer.from(p, 'base64url').toString()); return c.exp > Date.now() / 1000 ? c : null;
}

function createApp({ dir, orgNames = ['HospitalA', 'HospitalB', 'HospitalC', 'LabX'] }) {
  const orgs = orgNames.map((n) => new Org(n));
  const ledger = new Ledger({ orgs, minEndorsements: 2 });
  const contract = new HealthContract(ledger, orgs);
  const store = new OffChainStore(dir);

  const send = (res, code, body) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(body === undefined ? '' : JSON.stringify(body)); };
  const body = (req) => new Promise((ok, no) => { let b = ''; req.on('data', (c) => { b += c; if (b.length > 100000) { no(new Error('too large')); req.destroy(); } }); req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch { no(new Error('bad json')); } }); });

  const server = http.createServer(async (req, res) => {
    try {
      const u = new URL(req.url, 'http://x'); const parts = u.pathname.split('/').filter(Boolean);   // ['v1','records',':id',...]
      if (parts[0] !== 'v1') return send(res, 404, { error: 'not_found' });
      const m = /^Bearer (\S+)$/.exec(req.headers.authorization || ''); const actor = m && verify(m[1]);
      if (!actor) return send(res, 401, { error: 'unauthorized' });          // actor = { id, role, org }

      // POST /v1/records
      if (req.method === 'POST' && parts[1] === 'records' && parts.length === 2) {
        const b = await body(req);
        if (!/^[A-Za-z0-9_-]{3,40}$/.test(b.patientId || '') || typeof b.content !== 'string' || !b.content) return send(res, 422, { error: 'validation_failed' });
        const recordId = 'rec_' + crypto.randomBytes(5).toString('hex');
        const hash = store.put(recordId, b.content);                         // 1. encrypt + store OFF-chain
        const block = contract.registerRecord(recordId, b.patientId, hash, actor);   // 2. only the hash goes ON-chain
        return send(res, 201, { recordId, contentHash: hash, block: block.index });
      }
      // GET /v1/records/:id  (consent check + integrity check + audit entry)
      if (req.method === 'GET' && parts[1] === 'records' && parts.length === 3) {
        const rec = contract.getRecord(parts[2]); if (!rec) return send(res, 404, { error: 'not_found' });
        const purpose = u.searchParams.get('purpose') || 'treatment';
        const allowed = rec.ownerOrg === actor.org || contract.hasConsent(rec.patientId, actor.org);
        contract.recordAccess(rec.recordId, actor.org, purpose, allowed, actor);          // denied attempts are logged too
        if (!allowed) return send(res, 403, { error: 'no_consent', message: 'Patient has not consented to this organisation' });
        if (store.rawHash(rec.recordId) === null) return send(res, 410, { error: 'erased', message: 'Content was erased; only the hash remains' });
        if (store.rawHash(rec.recordId) !== rec.contentHash) return send(res, 409, { error: 'integrity_failure', message: 'Stored data does not match the hash on the ledger' });
        let content; try { content = store.get(rec.recordId); } catch { return send(res, 409, { error: 'integrity_failure' }); }
        return send(res, 200, { recordId: rec.recordId, patientId: rec.patientId, content });
      }
      // GET /v1/records/:id/audit
      if (req.method === 'GET' && parts[1] === 'records' && parts[3] === 'audit') {
        const rec = contract.getRecord(parts[2]); if (!rec) return send(res, 404, { error: 'not_found' });
        if (!(actor.role === 'patient' && actor.id === rec.patientId) && actor.role !== 'auditor') return send(res, 403, { error: 'forbidden' });
        return send(res, 200, { recordId: rec.recordId, events: contract.auditTrail(rec.recordId) });
      }
      // POST /v1/patients/:id/consents   DELETE /v1/patients/:id/consents/:org
      if (parts[1] === 'patients' && parts[3] === 'consents') {
        if (req.method === 'POST') {
          const b = await body(req);
          if (!orgNames.includes(b.orgId) || !Number.isInteger(b.days) || b.days < 1 || b.days > 365) return send(res, 422, { error: 'validation_failed' });
          const blk = contract.grantConsent(parts[2], b.orgId, String(b.purpose || 'treatment').slice(0, 40), b.days, actor);
          return send(res, 201, { granted: true, block: blk.index });
        }
        if (req.method === 'DELETE' && parts[4]) { contract.revokeConsent(parts[2], parts[4], actor); return send(res, 204); }
      }
      // DELETE /v1/records/:id/content  (right to erasure -> crypto-shredding, chain keeps only the hash)
      if (req.method === 'DELETE' && parts[1] === 'records' && parts[3] === 'content') {
        const rec = contract.getRecord(parts[2]); if (!rec) return send(res, 404, { error: 'not_found' });
        if (!(actor.role === 'patient' && actor.id === rec.patientId) && rec.ownerOrg !== actor.org) return send(res, 403, { error: 'forbidden' });
        store.erase(rec.recordId);
        contract.submit('ERASURE', { recordId: rec.recordId }, actor);        // log that erasure happened (no personal data)
        return send(res, 200, { erased: true });
      }
      // GET /v1/ledger/verify
      if (req.method === 'GET' && parts[1] === 'ledger' && parts[2] === 'verify') return send(res, 200, ledger.verify());
      return send(res, 404, { error: 'not_found' });
    } catch (e) {
      const map = { FORBIDDEN: 403, CONFLICT: 409, ENDORSEMENT: 503 };
      if (map[e.code]) return send(res, map[e.code], { error: e.code.toLowerCase(), message: e.message });
      if (e.message === 'bad json' || e.message === 'too large') return send(res, 400, { error: 'bad_request' });
      console.error(e); return send(res, 500, { error: 'internal' });          // no stack traces to clients
    }
  });
  return { server, ledger, contract, store, makeToken };
}

if (require.main === module) {
  const { server } = createApp({ dir: process.env.DATA_DIR || './data' });
  server.listen(Number(process.env.PORT) || 8086, () => console.log('record service on :8086'));
}
module.exports = { createApp };
