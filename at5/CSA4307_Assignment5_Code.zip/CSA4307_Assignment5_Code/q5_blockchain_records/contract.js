'use strict';
/**
 * "Smart contract" (chaincode) rules. State is rebuilt from the ledger, so nobody can change it without leaving a trace.
 * Only HASHES, CONSENT and ACCESS EVENTS are stored here. No medical data ever touches the chain.
 */
const { Ledger } = require('./ledger');

class HealthContract {
  constructor(ledger, orgs) { this.ledger = ledger; this.orgs = orgs; }

  /** Create a transaction and have the peers endorse it (in Fabric the client sends a proposal to several peers). */
  submit(type, data, actor) {
    const tx = { type, data, actor, ts: new Date().toISOString() };
    const digest = Ledger.txDigest(tx);
    const endorsements = this.orgs.map((o) => ({ org: o.name, signature: o.sign(digest) }));
    return this.ledger.append(tx, endorsements);
  }

  // ----- reading current state (replay) -----
  #state() {
    const records = new Map(), consents = new Map();
    for (const t of this.ledger.transactions) {
      const d = t.data;
      if (t.type === 'REGISTER_RECORD') records.set(d.recordId, { ...d, ownerOrg: t.actor.org });
      if (t.type === 'GRANT_CONSENT') consents.set(`${d.patientId}|${d.orgId}`, { purpose: d.purpose, expiresAt: d.expiresAt, active: true });
      if (t.type === 'REVOKE_CONSENT') { const c = consents.get(`${d.patientId}|${d.orgId}`); if (c) c.active = false; }
    }
    return { records, consents };
  }
  getRecord(recordId) { return this.#state().records.get(recordId) || null; }
  hasConsent(patientId, orgId, now = Date.now()) {
    const c = this.#state().consents.get(`${patientId}|${orgId}`);
    return !!c && c.active && new Date(c.expiresAt).getTime() > now;
  }
  auditTrail(recordId) {
    return this.ledger.transactions.filter((t) => t.type === 'ACCESS' && t.data.recordId === recordId)
      .map((t) => ({ at: t.ts, org: t.data.orgId, by: t.actor.id, purpose: t.data.purpose, granted: t.data.granted, block: t.block }));
  }

  // ----- writing -----
  registerRecord(recordId, patientId, contentHash, actor) {
    if (!['hospital', 'lab'].includes(actor.role)) throw Object.assign(new Error('only hospitals/labs register records'), { code: 'FORBIDDEN' });
    if (this.getRecord(recordId)) throw Object.assign(new Error('record already exists'), { code: 'CONFLICT' });
    return this.submit('REGISTER_RECORD', { recordId, patientId, contentHash }, actor);
  }
  grantConsent(patientId, orgId, purpose, days, actor) {
    if (actor.role !== 'patient' || actor.id !== patientId) throw Object.assign(new Error('only the patient can grant consent'), { code: 'FORBIDDEN' });
    const expiresAt = new Date(Date.now() + days * 86400000).toISOString();
    return this.submit('GRANT_CONSENT', { patientId, orgId, purpose, expiresAt }, actor);
  }
  revokeConsent(patientId, orgId, actor) {
    if (actor.role !== 'patient' || actor.id !== patientId) throw Object.assign(new Error('only the patient can revoke consent'), { code: 'FORBIDDEN' });
    return this.submit('REVOKE_CONSENT', { patientId, orgId }, actor);
  }
  recordAccess(recordId, orgId, purpose, granted, actor) {                       // BOTH allowed and denied attempts are logged
    return this.submit('ACCESS', { recordId, orgId, purpose, granted }, actor);
  }
}
module.exports = { HealthContract };
