'use strict';
/** Off-chain encrypted storage. AES-256-GCM per record; each record key (DEK) is wrapped by a master key (KEK). */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { sha256 } = require('./ledger');

class OffChainStore {
  constructor(dir, kek = Buffer.from(process.env.KEK_HEX || '00'.repeat(32), 'hex')) {   // production: KMS / HSM, never an env default
    this.dir = dir; this.kek = kek;
    fs.mkdirSync(path.join(dir, 'data'), { recursive: true }); fs.mkdirSync(path.join(dir, 'keys'), { recursive: true });
  }
  #p(kind, id) { if (!/^[A-Za-z0-9_-]{1,64}$/.test(id)) throw new Error('bad id'); return path.join(this.dir, kind, id + '.json'); }

  /** @returns {string} SHA-256 of the ciphertext package: this is what goes on the chain */
  put(recordId, plaintext) {
    const dek = crypto.randomBytes(32);
    const iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv('aes-256-gcm', dek, iv);
    const ct = Buffer.concat([c.update(plaintext, 'utf8'), c.final()]);
    const pkg = { iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), ct: ct.toString('base64') };

    const wiv = crypto.randomBytes(12);                                      // wrap the DEK with the KEK
    const w = crypto.createCipheriv('aes-256-gcm', this.kek, wiv);
    const wrapped = Buffer.concat([w.update(dek), w.final()]);
    fs.writeFileSync(this.#p('keys', recordId), JSON.stringify({ iv: wiv.toString('base64'), tag: w.getAuthTag().toString('base64'), key: wrapped.toString('base64') }));
    const text = JSON.stringify(pkg);
    fs.writeFileSync(this.#p('data', recordId), text);
    return sha256(text);
  }
  rawHash(recordId) { try { return sha256(fs.readFileSync(this.#p('data', recordId), 'utf8')); } catch { return null; } }

  get(recordId) {
    let pkg, k;
    try { pkg = JSON.parse(fs.readFileSync(this.#p('data', recordId), 'utf8')); k = JSON.parse(fs.readFileSync(this.#p('keys', recordId), 'utf8')); }
    catch { return null; }                                                   // erased or never existed
    const u = crypto.createDecipheriv('aes-256-gcm', this.kek, Buffer.from(k.iv, 'base64'));
    u.setAuthTag(Buffer.from(k.tag, 'base64'));
    const dek = Buffer.concat([u.update(Buffer.from(k.key, 'base64')), u.final()]);
    const d = crypto.createDecipheriv('aes-256-gcm', dek, Buffer.from(pkg.iv, 'base64'));
    d.setAuthTag(Buffer.from(pkg.tag, 'base64'));
    return Buffer.concat([d.update(Buffer.from(pkg.ct, 'base64')), d.final()]).toString('utf8');   // throws if ciphertext was altered
  }

  /** CRYPTO-SHREDDING: destroy the key (and data). The hash on the chain can no longer be linked to any readable data. */
  erase(recordId) {
    for (const kind of ['keys', 'data']) { try { fs.unlinkSync(this.#p(kind, recordId)); } catch { /* already gone */ } }
  }
}
module.exports = { OffChainStore };
