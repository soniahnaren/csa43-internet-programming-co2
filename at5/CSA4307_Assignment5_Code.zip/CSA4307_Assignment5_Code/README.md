# CSA4307 Internet Programming – Assignment 5 – Code base

| Folder | Question | Technology | Main files |
|---|---|---|---|
| `q1_ai_triage/` | Q1 AI triage behind REST **and** SOAP | PHP 8.1+, SQLite | `rest_api.php`, `soap_server.php`, `triage.wsdl`, `auth.php`, `ratelimit.php`, `validate.php`, `classifier.php` |
| `q2_wsdl_student_result/` | Q2 WSDL + testing | PHP SOAP | `student_result.wsdl`, `server.php`, `client.php`, `tests/`, `run_tests.sh`, `postman_collection.json` |
| `q3_library_soap/` | Q3 database-driven SOAP service | PHP SOAP + PDO | `library.wsdl`, `LibraryService.php`, `db.php`, `schema_mysql.sql`, `client.php`, `concurrency_test.sh` |
| `q4_realtime_ambulance/` | Q4 WebSocket live tracking | Node.js 18+ and `ws` | `server.js`, `auth.js`, `simulator.js`, `public/index.html`, `test_client.js` |
| `q5_blockchain_records/` | Q5 permissioned-ledger model | Node.js 18+ (no dependencies) | `ledger.js`, `contract.js`, `offchain.js`, `api.js`, `test.js`, `chaincode/healthrecords.js` |

Requirements: PHP with `soap`, `curl`, `pdo_sqlite` (and `pdo_mysql` for the MySQL variant of Q3), Node.js 18+, `curl`.

## Q1 – AI triage (REST + SOAP)
```bash
cd q1_ai_triage
php -S 127.0.0.1:8081 rest_api.php &         && ./tests.sh          # REST  (demo key: demo-key-clinic-1)
php -S 127.0.0.1:8082 soap_server.php &      && php soap_client.php "Severe chest pain"   # SOAP + WS-Security
```
The built-in `KeywordClassifier` stands in for the trained model; set `MODEL_URL` to call a real model server instead.

## Q2 – WSDL and testing
```bash
cd q2_wsdl_student_result
php -S 127.0.0.1:8083 server.php &
./run_tests.sh                       # 8 automated checks (valid, invalid, missing, not found, XXE, no/wrong key)
php client.php 192311234 5           # SoapClient built from the WSDL
```
Import `student_result.wsdl` into SoapUI (New SOAP project) or `postman_collection.json` into Postman.

## Q3 – Library SOAP service
```bash
cd q3_library_soap
PHP_CLI_SERVER_WORKERS=6 php -S 127.0.0.1:8084 server.php &
php client.php program               # search -> details -> issue
./concurrency_test.sh                # 6 parallel requests, 2 copies: exactly 2 succeed
```
Demo keys: `desk-key-456` (may issue books), `public-key-123` (read only). For MySQL run `schema_mysql.sql` and set `LIB_DSN`, `LIB_USER`, `LIB_PASS`.

## Q4 – Live ambulance data
```bash
cd q4_realtime_ambulance && npm install
npm test                             # 11 automated checks
DEMO=1 node server.js &              # open http://127.0.0.1:8085 ; then:  node simulator.js AMB-07
```
(`DEMO=1` enables a token endpoint for the demo page only. For WSS set `TLS_KEY` and `TLS_CERT`.)

## Q5 – Blockchain records
```bash
cd q5_blockchain_records && npm test      # 21 checks: consent, audit trail, tamper detection, erasure
node api.js                                # REST service on :8086
```

## What was tested
* Q1, Q2, Q3: executed with PHP 8.3 against the built-in web server (outputs are quoted in the answers). The MySQL variant of Q3 was not run (SQLite was used); the `FOR UPDATE` lock is the only difference.
* Q4: 11 automated WebSocket checks passed in Node 22; the dashboard page `public/index.html` was served but not opened in a real browser, and WSS/TLS was not exercised.
* Q5: 21 automated checks passed. `chaincode/healthrecords.js` is a reference sample that was **not** run on a Hyperledger Fabric network.
* All secrets, keys and users in the code are demo values and must be replaced (vault / KMS / environment).
