<?php
declare(strict_types=1);
/** Legacy-system style client. Usage: php soap_client.php "message text" [password] */
const WSSE = 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd';
const WSU  = 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd';

function wsse_header(string $user, string $password): SoapHeader
{
    $nonce   = random_bytes(16);
    $created = gmdate('Y-m-d\TH:i:s\Z');
    $digest  = base64_encode(sha1($nonce . $created . $password, true));
    $xml = '<wsse:Security xmlns:wsse="' . WSSE . '" xmlns:wsu="' . WSU . '"><wsse:UsernameToken>'
         . '<wsse:Username>' . htmlspecialchars($user, ENT_XML1) . '</wsse:Username>'
         . '<wsse:Password Type="PasswordDigest">' . $digest . '</wsse:Password>'
         . '<wsse:Nonce>' . base64_encode($nonce) . '</wsse:Nonce><wsu:Created>' . $created . '</wsu:Created>'
         . '</wsse:UsernameToken></wsse:Security>';
    return new SoapHeader(WSSE, 'Security', new SoapVar($xml, XSD_ANYXML), false);
}

$client = new SoapClient(__DIR__ . '/triage.wsdl', [
    'location' => getenv('TRIAGE_SOAP_URL') ?: 'http://127.0.0.1:8082/soap_server.php',
    'trace' => true, 'exceptions' => true, 'cache_wsdl' => WSDL_CACHE_NONE, 'connection_timeout' => 5]);
$client->__setSoapHeaders([wsse_header('billing-system', $argv[2] ?? 'S0ap-Pa55')]);

try {
    $res = $client->classifyUrgency(['patientRef' => 'PT-000200',
                                     'message' => $argv[1] ?? 'Severe chest pain since morning', 'language' => 'en']);
    print_r($res);
} catch (SoapFault $f) {
    echo "SOAP FAULT [{$f->faultcode}]: {$f->faultstring}\n";
}
if (getenv('SHOW_XML')) { echo "\n--- request ---\n", $client->__getLastRequest(), "\n--- response ---\n", $client->__getLastResponse(), "\n"; }
