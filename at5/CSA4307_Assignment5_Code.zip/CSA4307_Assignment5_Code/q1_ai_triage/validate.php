<?php
declare(strict_types=1);

/** @return array{0: array<string,string>, 1: array<string,string>} [errors, clean] */
function validate_triage_input(mixed $in): array
{
    $errors = []; $clean = [];
    if (!is_array($in)) { return [['body' => 'JSON object expected'], []]; }

    $msg = $in['message'] ?? null;
    if (!is_string($msg)) {
        $errors['message'] = 'message is required and must be a string';
    } else {
        $msg = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', trim($msg)) ?? '';   // strip control characters
        $len = mb_strlen($msg);
        if ($len < 5 || $len > 1000) { $errors['message'] = 'message must be 5 to 1000 characters'; }
        $clean['message'] = $msg;
    }

    $ref = $in['patient_ref'] ?? null;
    if (!is_string($ref) || preg_match('/^[A-Za-z0-9_-]{6,40}\z/', $ref) !== 1) {
        $errors['patient_ref'] = 'patient_ref must be a 6-40 character pseudonymous id (letters, digits, - _)';
    } else {
        $clean['patient_ref'] = $ref;                       // no name, phone number or address is accepted
    }

    $lang = $in['language'] ?? 'en';
    if (!in_array($lang, ['en', 'ta', 'hi'], true)) { $errors['language'] = 'language must be en, ta or hi'; }
    $clean['language'] = is_string($lang) ? $lang : 'en';

    return [$errors, $clean];
}
