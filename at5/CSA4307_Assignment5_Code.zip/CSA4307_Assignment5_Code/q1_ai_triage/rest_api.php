<?php
declare(strict_types=1);
/**
 * REST API (version 1)
 *   GET  /v1/health
 *   POST /v1/triage-requests          -> 201 Created + Location
 *   GET  /v1/triage-requests/{id}     -> 200 / 404
 * Run:  php -S 127.0.0.1:8081 rest_api.php
 */
require __DIR__ . '/validate.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/ratelimit.php';
require __DIR__ . '/core.php';
$cfg = require __DIR__ . '/config.php';

function respond(int $code, array $body, array $headers = []): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store');                       // patient data must not be cached
    header('X-Content-Type-Options: nosniff');
    foreach ($headers as $k => $v) { header("$k: $v"); }
    echo json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
function fail(int $code, string $error, string $msg, array $details = [], array $h = []): never
{
    respond($code, ['error' => ['code' => $error, 'message' => $msg] + ($details ? ['details' => $details] : [])], $h);
}

$method = $_SERVER['REQUEST_METHOD'];
$path   = rtrim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/', '/');

if ($path === '/v1/health') { respond(200, ['status' => 'ok', 'version' => 'v1']); }

$isCreate = $path === '/v1/triage-requests';
$isRead   = preg_match('#^/v1/triage-requests/(tr_[a-f0-9]{12})$#', $path, $m) === 1;
if (!$isCreate && !$isRead) { fail(404, 'not_found', 'Unknown resource'); }
if (($isCreate && $method !== 'POST') || ($isRead && $method !== 'GET')) {
    fail(405, 'method_not_allowed', 'Method not allowed', [], ['Allow' => $isCreate ? 'POST' : 'GET']);
}

// ---- authentication (who are you?) ----
$auth = authenticate_rest($cfg);
if (!$auth) { fail(401, 'unauthorized', 'Valid API key or bearer token required', [], ['WWW-Authenticate' => 'Bearer']); }

// ---- authorisation (what may you do?) ----
$need = $isCreate ? 'triage:write' : 'triage:read';
if (!in_array($need, $auth['scopes'], true)) { fail(403, 'forbidden', "Missing scope $need"); }

// ---- rate limiting ----
$rl = rate_limit($auth['client'], $cfg['rate_limit']['capacity'], $cfg['rate_limit']['refill_per_sec']);
$rlHeaders = ['X-RateLimit-Limit' => (string)$cfg['rate_limit']['capacity'], 'X-RateLimit-Remaining' => (string)$rl['remaining']];
if (!$rl['allowed']) { fail(429, 'rate_limited', 'Too many requests', [], $rlHeaders + ['Retry-After' => (string)$rl['retry_after']]); }

$pdo = triage_pdo($cfg);

if ($isRead) {
    $st = $pdo->prepare('SELECT * FROM triage_requests WHERE id = :id AND client = :c');   // a client sees only its own rows
    $st->execute([':id' => $m[1], ':c' => $auth['client']]);
    $row = $st->fetch();
    if (!$row) { fail(404, 'not_found', 'Triage request not found', [], $rlHeaders); }
    respond(200, ['id' => $row['id'], 'urgency' => $row['urgency'], 'suggested_department' => $row['department'],
                  'confidence' => (float)$row['confidence'], 'needs_human_review' => (bool)$row['needs_review'],
                  'model_version' => $row['model_version'], 'created_at' => $row['created_at']], $rlHeaders);
}

// ---- POST /v1/triage-requests ----
if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) {
    fail(415, 'unsupported_media_type', 'Content-Type must be application/json', [], $rlHeaders);
}
$raw = file_get_contents('php://input', false, null, 0, 8193);
if (strlen($raw) > 8192) { fail(413, 'payload_too_large', 'Body limited to 8 KB', [], $rlHeaders); }
try { $input = json_decode($raw, true, 8, JSON_THROW_ON_ERROR); }
catch (JsonException) { fail(400, 'invalid_json', 'Body is not valid JSON', [], $rlHeaders); }

[$errors, $clean] = validate_triage_input($input);
if ($errors) { fail(422, 'validation_failed', 'Input validation failed', $errors, $rlHeaders); }

$r = run_triage($pdo, $cfg, $clean, $auth['client']);
respond(201, ['id' => $r['id'], 'urgency' => $r['urgency'], 'suggested_department' => $r['department'],
              'confidence' => $r['confidence'], 'needs_human_review' => $r['needs_human_review'],
              'model_version' => $r['model_version'], 'disclaimer' => $r['disclaimer']],
        $rlHeaders + ['Location' => '/v1/triage-requests/' . $r['id']]);
