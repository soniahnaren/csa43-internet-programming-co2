<?php
declare(strict_types=1);

interface Classifier
{
    /** @return array{urgency:string,department:string,confidence:float,model_version:string} */
    public function classify(string $text): array;
}

/** Stand-in for the trained model so the service can be run and tested offline. */
final class KeywordClassifier implements Classifier
{
    private const HIGH = ['chest pain', 'cannot breathe', "can't breathe", 'shortness of breath', 'unconscious',
                          'severe bleeding', 'stroke', 'seizure', 'face drooping', 'suicidal'];
    private const MEDIUM = ['fever', 'vomiting', 'fracture', 'infection', 'persistent', 'dizzy', 'rash', 'swelling'];
    private const DEPT = [
        'Cardiology'         => ['chest pain', 'palpitation'],
        'Pulmonology'        => ['breathe', 'breath', 'cough', 'asthma'],
        'Neurology'          => ['stroke', 'seizure', 'face drooping', 'numb', 'migraine'],
        'Orthopaedics'       => ['fracture', 'bone', 'joint', 'sprain'],
        'Gastroenterology'   => ['stomach', 'vomiting', 'abdominal', 'diarrhoea'],
        'Dermatology'        => ['rash', 'itching', 'skin'],
    ];

    public function __construct(private string $version) {}

    public function classify(string $text): array
    {
        $t = mb_strtolower($text);
        $hits = static fn(array $words): int => count(array_filter($words, static fn($w) => str_contains($t, $w)));

        $high = $hits(self::HIGH);
        $med  = $hits(self::MEDIUM);
        [$urgency, $conf] = match (true) {
            $high > 0 => ['high',   min(0.95, 0.75 + 0.10 * $high)],
            $med  > 0 => ['medium', min(0.85, 0.60 + 0.10 * $med)],
            default   => ['low',    0.55],
        };

        $department = 'General Medicine';
        foreach (self::DEPT as $dept => $words) {
            if ($hits($words) > 0) { $department = $dept; break; }
        }
        return ['urgency' => $urgency, 'department' => $department,
                'confidence' => round($conf, 2), 'model_version' => $this->version];
    }
}

/** Calls the real model server (e.g. a Python/ONNX service on the private network). */
final class HttpModelClient implements Classifier
{
    public function __construct(private string $url, private float $timeoutSec = 2.0) {}

    public function classify(string $text): array
    {
        $ch = curl_init($this->url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT_MS => (int)($this->timeoutSec * 1000),     // latency budget
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode(['text' => $text], JSON_THROW_ON_ERROR),
        ]);
        $raw = curl_exec($ch);
        if ($raw === false || curl_getinfo($ch, CURLINFO_RESPONSE_CODE) !== 200) {
            throw new RuntimeException('Model service unavailable');
        }
        return json_decode($raw, true, 8, JSON_THROW_ON_ERROR);
    }
}

/** Safety net around ANY model: low confidence is escalated and high urgency always gets a human check. */
function apply_safety_rules(array $r): array
{
    $levels = ['low', 'medium', 'high'];
    $review = false;
    if ($r['confidence'] < 0.60 && $r['urgency'] !== 'high') {           // uncertain -> err on the safe side
        $r['urgency'] = $levels[min(2, array_search($r['urgency'], $levels, true) + 1)];
        $review = true;
    }
    if ($r['urgency'] === 'high') { $review = true; }
    $r['needs_human_review'] = $review;
    $r['disclaimer'] = 'Decision support only. Not a diagnosis. In an emergency call the ambulance service.';
    return $r;
}
