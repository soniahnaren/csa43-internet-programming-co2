<?php
declare(strict_types=1);
/* Demo configuration. In production read every secret from environment variables / a vault. */
return [
    'db'            => getenv('TRIAGE_DB') ?: sys_get_temp_dir() . '/triage_demo.sqlite',
    // API keys are stored only as SHA-256 hashes (the plain demo key is: demo-key-clinic-1)
    'api_keys'      => [
        hash('sha256', 'demo-key-clinic-1') => ['client' => 'clinic-1', 'scopes' => ['triage:write', 'triage:read']],
    ],
    'jwt_secret'    => getenv('JWT_SECRET') ?: 'dev-secret-change-me',
    'jwt_issuer'    => 'https://auth.hospital.example',
    // WS-Security UsernameToken accounts for the legacy partner systems (password kept server-side only)
    'soap_users'    => ['billing-system' => 'S0ap-Pa55'],
    'rate_limit'    => ['capacity' => 5, 'refill_per_sec' => 1.0],   // token bucket per client
    'model_url'     => getenv('MODEL_URL') ?: '',                    // empty => built-in demo classifier
    'model_version' => 'triage-rules-1.0',
];
