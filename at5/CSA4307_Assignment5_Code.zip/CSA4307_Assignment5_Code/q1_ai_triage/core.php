<?php
declare(strict_types=1);
require_once __DIR__ . '/classifier.php';

function triage_pdo(array $cfg): PDO
{
    $pdo = new PDO('sqlite:' . $cfg['db'], null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    $pdo->exec('CREATE TABLE IF NOT EXISTS triage_requests (
        id TEXT PRIMARY KEY, client TEXT NOT NULL, patient_ref TEXT NOT NULL, urgency TEXT NOT NULL,
        department TEXT NOT NULL, confidence REAL NOT NULL, needs_review INTEGER NOT NULL,
        model_version TEXT NOT NULL, created_at TEXT NOT NULL)');          // NOTE: message text is NOT stored
    return $pdo;
}

/** Shared by REST and SOAP so both interfaces give identical answers. */
function run_triage(PDO $pdo, array $cfg, array $clean, string $client): array
{
    $model = $cfg['model_url'] !== '' ? new HttpModelClient($cfg['model_url'])
                                      : new KeywordClassifier($cfg['model_version']);
    try {
        $r = apply_safety_rules($model->classify($clean['message']));
    } catch (Throwable $e) {                                   // model down/slow: fail safe, never silently "low"
        $r = apply_safety_rules(['urgency' => 'medium', 'department' => 'General Medicine',
                                 'confidence' => 0.0, 'model_version' => 'fallback']);
    }
    $id = 'tr_' . bin2hex(random_bytes(6));
    $pdo->prepare('INSERT INTO triage_requests VALUES (:id,:c,:p,:u,:d,:cf,:r,:m,:t)')->execute([
        ':id' => $id, ':c' => $client, ':p' => $clean['patient_ref'], ':u' => $r['urgency'], ':d' => $r['department'],
        ':cf' => $r['confidence'], ':r' => (int)$r['needs_human_review'], ':m' => $r['model_version'],
        ':t' => gmdate('c')]);
    return ['id' => $id] + $r;
}
