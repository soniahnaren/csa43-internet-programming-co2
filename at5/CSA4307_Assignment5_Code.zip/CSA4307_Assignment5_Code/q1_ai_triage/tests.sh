#!/bin/sh
# REST smoke tests. Start first:  php -S 127.0.0.1:8081 rest_api.php
U=http://127.0.0.1:8081; K='X-API-Key: demo-key-clinic-1'; J='Content-Type: application/json'
echo "health:";        curl -s $U/v1/health; echo
echo "no auth (401):"; curl -s -o /dev/null -w '%{http_code}\n' -X POST $U/v1/triage-requests
echo "create (201):";  curl -si $U/v1/triage-requests -H "$K" -H "$J" -d '{"patient_ref":"PT-000123","message":"Severe chest pain and shortness of breath"}' | grep -Ei '^HTTP|^location|^\{'
echo "invalid (422):"; curl -s $U/v1/triage-requests -H "$K" -H "$J" -d '{"patient_ref":"x","message":"hi"}'; echo
echo "bad JSON (400):"; curl -s -o /dev/null -w '%{http_code}\n' $U/v1/triage-requests -H "$K" -H "$J" -d '{oops'
echo "rate limit (capacity 5, expect 429 after the 5th):"
for i in 1 2 3 4 5 6 7; do curl -s -o /dev/null -w '%{http_code} ' $U/v1/triage-requests/tr_000000000000 -H "$K"; done; echo
