<?php
declare(strict_types=1);

/** Token bucket per client. Production: use Redis or the API gateway instead of files. */
function rate_limit(string $client, int $capacity, float $refillPerSec): array
{
    $file = sys_get_temp_dir() . '/triage_rl_' . md5($client) . '.json';
    $fh = fopen($file, 'c+');
    flock($fh, LOCK_EX);                                       // concurrent requests must not race
    $s = json_decode((string)stream_get_contents($fh), true) ?: ['tokens' => (float)$capacity, 'ts' => microtime(true)];
    $now = microtime(true);
    $s['tokens'] = min($capacity, $s['tokens'] + ($now - $s['ts']) * $refillPerSec);
    $s['ts'] = $now;
    $allowed = $s['tokens'] >= 1;
    if ($allowed) { $s['tokens'] -= 1; }
    ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($s));
    flock($fh, LOCK_UN); fclose($fh);
    return ['allowed' => $allowed, 'remaining' => (int)floor($s['tokens']),
            'retry_after' => $allowed ? 0 : (int)ceil((1 - $s['tokens']) / $refillPerSec)];
}
