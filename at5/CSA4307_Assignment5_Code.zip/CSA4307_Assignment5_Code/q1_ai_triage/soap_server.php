<?php
declare(strict_types=1);
/** SOAP interface for legacy partner systems. Run: php -S 127.0.0.1:8082 soap_server.php */
require __DIR__ . '/validate.php';
require __DIR__ . '/core.php';
$cfg = require __DIR__ . '/config.php';

const WSSE = 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd';
const WSU  = 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd';

/** Verify the WS-Security UsernameToken (PasswordDigest = Base64(SHA1(nonce + created + password))). */
function verify_wsse(string $rawXml, array $users): string
{
    $dom = new DOMDocument();
    if (!@$dom->loadXML($rawXml, LIBXML_NONET)) { throw new SoapFault('Client', 'Malformed XML'); }
    $xp = new DOMXPath($dom);
    $xp->registerNamespace('wsse', WSSE);
    $xp->registerNamespace('wsu', WSU);
    $tok = $xp->query('//wsse:Security/wsse:UsernameToken')->item(0);
    if (!$tok) { throw new SoapFault('wsse:SecurityTokenUnavailable', 'WS-Security header missing'); }

    $user    = $xp->evaluate('string(wsse:Username)', $tok);
    $digest  = $xp->evaluate('string(wsse:Password)', $tok);
    $nonceB  = $xp->evaluate('string(wsse:Nonce)', $tok);
    $created = $xp->evaluate('string(wsu:Created)', $tok);

    $age = abs(time() - (int)strtotime($created));
    if ($created === '' || $age > 300) { throw new SoapFault('wsse:FailedAuthentication', 'Token expired or timestamp invalid'); }
    $password = $users[$user] ?? null;
    $expected = $password === null ? '' : base64_encode(sha1(base64_decode($nonceB) . $created . $password, true));
    if ($password === null || !hash_equals($expected, $digest)) {
        throw new SoapFault('wsse:FailedAuthentication', 'Invalid credentials');
    }
    // replay protection: a nonce may be used only once inside the validity window
    $f = sys_get_temp_dir() . '/triage_nonces.json';
    $seen = is_file($f) ? (json_decode((string)file_get_contents($f), true) ?: []) : [];
    $seen = array_filter($seen, static fn($t) => $t > time() - 300);
    if (isset($seen[$nonceB])) { throw new SoapFault('wsse:FailedAuthentication', 'Replay detected'); }
    $seen[$nonceB] = time();
    file_put_contents($f, json_encode($seen), LOCK_EX);
    return $user;
}

final class TriageSoapService
{
    public function __construct(private array $cfg, private string $client) {}

    public function classifyUrgency(object $p): array
    {
        [$errors, $clean] = validate_triage_input([
            'patient_ref' => $p->patientRef ?? null, 'message' => $p->message ?? null, 'language' => $p->language ?? 'en']);
        if ($errors) {
            throw new SoapFault('Client', 'Validation failed', null,
                (object)['TriageFault' => ['code' => 'VALIDATION', 'message' => implode('; ', $errors)]]);
        }
        $r = run_triage(triage_pdo($this->cfg), $this->cfg, $clean, $this->client);
        return ['requestId' => $r['id'], 'urgency' => $r['urgency'], 'department' => $r['department'],
                'confidence' => $r['confidence'], 'needsHumanReview' => $r['needs_human_review'],
                'modelVersion' => $r['model_version']];
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET' && isset($_GET['wsdl'])) {      // publish the contract
    header('Content-Type: text/xml; charset=UTF-8');
    readfile(__DIR__ . '/triage.wsdl');
    exit;
}

$raw = file_get_contents('php://input');
$server = new SoapServer(__DIR__ . '/triage.wsdl', ['cache_wsdl' => WSDL_CACHE_NONE]);
try {
    $client = verify_wsse($raw, $cfg['soap_users']);
    $server->setObject(new TriageSoapService($cfg, $client));
    $server->handle($raw);
} catch (SoapFault $f) {
    $server->fault($f->faultcode, $f->faultstring);        // returns a proper <soap:Fault> envelope
}
