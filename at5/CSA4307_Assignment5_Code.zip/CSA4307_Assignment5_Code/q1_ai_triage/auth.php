<?php
declare(strict_types=1);

function b64url_encode(string $s): string { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
function b64url_decode(string $s): string { return (string)base64_decode(strtr($s, '-_', '+/')); }

/** Issue an HS256 token. In real life an OAuth 2.0 authorisation server does this (client-credentials grant). */
function jwt_issue(array $claims, string $secret): string
{
    $h = b64url_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    $p = b64url_encode(json_encode($claims));
    return "$h.$p." . b64url_encode(hash_hmac('sha256', "$h.$p", $secret, true));
}

/** @return array|null claims if the token is valid */
function jwt_verify(string $token, string $secret, string $issuer): ?array
{
    $parts = explode('.', $token);
    if (count($parts) !== 3) { return null; }
    [$h, $p, $sig] = $parts;
    $header = json_decode(b64url_decode($h), true);
    if (($header['alg'] ?? '') !== 'HS256') { return null; }             // refuse alg=none and algorithm swapping
    $expected = b64url_encode(hash_hmac('sha256', "$h.$p", $secret, true));
    if (!hash_equals($expected, $sig)) { return null; }                  // constant-time compare
    $c = json_decode(b64url_decode($p), true);
    if (!is_array($c) || ($c['iss'] ?? '') !== $issuer || ($c['exp'] ?? 0) < time()) { return null; }
    return $c;
}

/** @return array{client:string,scopes:string[]}|null */
function authenticate_rest(array $cfg): ?array
{
    $key = $_SERVER['HTTP_X_API_KEY'] ?? '';
    if ($key !== '') {
        return $cfg['api_keys'][hash('sha256', $key)] ?? null;           // keys stored only as hashes
    }
    if (preg_match('/^Bearer\s+(\S+)$/', $_SERVER['HTTP_AUTHORIZATION'] ?? '', $m) === 1) {
        $c = jwt_verify($m[1], $cfg['jwt_secret'], $cfg['jwt_issuer']);
        return $c ? ['client' => (string)($c['sub'] ?? ''), 'scopes' => explode(' ', (string)($c['scope'] ?? ''))] : null;
    }
    return null;
}
